import SwiftUI
@main
struct TetrissyApp: App { var body: some Scene { WindowGroup { ModeSelectView() } } }
